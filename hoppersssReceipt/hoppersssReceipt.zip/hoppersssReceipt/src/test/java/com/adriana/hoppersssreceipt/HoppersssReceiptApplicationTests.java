package com.adriana.hoppersssreceipt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoppersssReceiptApplicationTests {

	@Test
	void contextLoads() {
	}

}
